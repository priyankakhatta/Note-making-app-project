package com.pro.priyankakhatta.notemakingapplication;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by priyankakhatta on 2017-12-14.
 */

public class NotesDBAdapter {

//    public static final String KEY_ROWID = "_id";
//    public static final String KEY_CODE = "code";
//    public static final String KEY_NAME = "name";
//    public static final String KEY_CONTINENT = "continent";
//    public static final String KEY_REGION = "region";

    public static final String KEY_NOTE_ROWID = "_id";
    public static final String KEY_N_SUB = "sub";
    public static final String KEY_N_DESC = "desc";
    public static final String KEY_N_DATETIME = "dt";
    public static final String KEY_N_LAT = "lat";
    public static final String KEY_N_LNG = "lng";
    public static final String KEY_N_IMG = "img";


//    private static final String TAG = "CountriesDbAdapter";
    private static final String N_TAG = "NotesDbAdapter";

    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

//    private static final String DATABASE_NAME = "World";
//    private static final String SQLITE_TABLE = "Country";
//    private static final int DATABASE_VERSION = 1;


    private static final String N_DATABASE_NAME = "NotesCollection";
    private static final String N_SQLITE_TABLE = "Notes";
    private static final int N_DATABASE_VERSION = 1;

    private final Context mCtx;

//    private static final String DATABASE_CREATE =
//            "CREATE TABLE if not exists " + SQLITE_TABLE + " (" +
//                    KEY_ROWID + " integer PRIMARY KEY autoincrement," +
//                    KEY_CODE + "," +
//                    KEY_NAME + "," +
//                    KEY_CONTINENT + "," +
//                    KEY_REGION + "," +
//                    " UNIQUE (" + KEY_CODE +"));";

    private static final String DATABASE_CREATE =
            "CREATE TABLE if not exists " + N_SQLITE_TABLE + " (" +
                    KEY_NOTE_ROWID + " integer PRIMARY KEY autoincrement," +
                    KEY_N_SUB + "," +
                    KEY_N_DESC + "," +
                    KEY_N_DATETIME + "," +
                    KEY_N_LAT + "," +
                    KEY_N_LNG + "," +
                    KEY_N_IMG +","+
                    " UNIQUE (" + KEY_NOTE_ROWID +"));";

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, N_DATABASE_NAME, null, N_DATABASE_VERSION);
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            Log.w(N_TAG, DATABASE_CREATE);
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(N_TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + N_SQLITE_TABLE);
            onCreate(db);
        }
    }

    public NotesDBAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    public NotesDBAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null) {
            mDbHelper.close();
        }
    }

    public long createNote(String sub, String desc, String dateTime, String lat, String lng, String img) {

       ContentValues initialValues = new ContentValues();

        initialValues.put(KEY_N_SUB, sub);
        initialValues.put(KEY_N_DESC, desc);
        initialValues.put(KEY_N_DATETIME, dateTime);
        initialValues.put(KEY_N_LAT, lat);
        initialValues.put(KEY_N_LNG, lng);
        initialValues.put(KEY_N_IMG, img);


        return mDb.insert(N_SQLITE_TABLE, null, initialValues);

    }


    public long updateNote(String id,String sub, String desc, String dateTime, String lat, String lng, String img) {

        ContentValues initialValues = new ContentValues();

        initialValues.put(KEY_N_SUB, sub);
        initialValues.put(KEY_N_DESC, desc);
        initialValues.put(KEY_N_DATETIME, dateTime);
        initialValues.put(KEY_N_LAT, lat);
        initialValues.put(KEY_N_LNG, lng);
        initialValues.put(KEY_N_IMG, img);


        return mDb.update(N_SQLITE_TABLE, initialValues,id+"="+KEY_NOTE_ROWID,null);

    }

    public boolean deleteAllNotes() {

        int doneDelete = 0;
        boolean bn = false;
        doneDelete = mDb.delete(N_SQLITE_TABLE, null , null);
        Log.w(N_TAG, Integer.toString(doneDelete));

        if(doneDelete == 0)
            bn = false;
         else
            bn = true;
        return bn;

    }
    public List<NoteModel> getData() {
        List<NoteModel> noteList= new ArrayList<NoteModel>();
        Cursor result = mDb.rawQuery("select * from "+N_SQLITE_TABLE , null);
        while(result.moveToNext()){
            noteList.add( new NoteModel(result.getString(result.getColumnIndex(KEY_N_SUB)),
                    result.getString(result.getColumnIndex(KEY_N_DESC)),
                    result.getString(result.getColumnIndex(KEY_N_DATETIME)),
                    result.getString(result.getColumnIndex(KEY_N_LAT)),
                    result.getString(result.getColumnIndex(KEY_N_LNG)),
                    result.getString(result.getColumnIndex(KEY_N_IMG))
                    ));

        }
        return noteList;
    }
    public Cursor fetchNoteByName(String inputText) throws SQLException {
        Log.w(N_TAG, inputText);
        Cursor mCursor = null;
        if (inputText == null || inputText.length () == 0) {
            mCursor = mDb.query(N_SQLITE_TABLE, new String[] {KEY_NOTE_ROWID, KEY_N_SUB,
                            KEY_N_DESC, KEY_N_DATETIME, KEY_N_LAT, KEY_N_LNG, KEY_N_IMG},
                    null, null, null, null, null);

        }
        else {
            mCursor = mDb.query(true, N_SQLITE_TABLE, new String[] {KEY_NOTE_ROWID, KEY_N_SUB,
                            KEY_N_DESC, KEY_N_DATETIME, KEY_N_LAT, KEY_N_LNG, KEY_N_IMG},
                    KEY_N_SUB  + " like '%" + inputText + "%'", null,
                    null, null, null, null);
        }

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchAllNotes() {

        Cursor mCursor = mDb.query(N_SQLITE_TABLE, new String[] {KEY_NOTE_ROWID, KEY_N_SUB,
                        KEY_N_DESC, KEY_N_DATETIME, KEY_N_LAT, KEY_N_LNG, KEY_N_IMG},
                null, null, null, null, null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }


    public Cursor fetchAllNotesByAlpha() {

        Cursor mCursor = mDb.query(N_SQLITE_TABLE, new String[] {KEY_NOTE_ROWID, KEY_N_SUB,
                        KEY_N_DESC, KEY_N_DATETIME, KEY_N_LAT, KEY_N_LNG, KEY_N_IMG},
                null, null, null, null, KEY_N_SUB);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public Cursor fetchAllNotesByDate() {

        Cursor mCursor = mDb.query(N_SQLITE_TABLE, new String[] {KEY_NOTE_ROWID, KEY_N_SUB,
                        KEY_N_DESC, KEY_N_DATETIME, KEY_N_LAT, KEY_N_LNG, KEY_N_IMG},
                null, null, null, null, KEY_N_DATETIME);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }
    public void insertNotes() {




    }

}