package com.pro.priyankakhatta.notemakingapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by priyankakhatta on 2017-12-14.
 */

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder> {

    private List<NoteModel> NoteModelsList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView sub, dt;
        public ImageView imgg;

        public MyViewHolder(View view) {
            super(view);
            sub = (TextView) view.findViewById(R.id.sub);
            dt = (TextView) view.findViewById(R.id.datetv);
//            imgg = (ImageView) view.findViewById(R.id.imag);
        }
    }


    public UserAdapter(List<NoteModel> NoteModelsList) {
        this.NoteModelsList = NoteModelsList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.listview_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        NoteModel NoteModel = NoteModelsList.get(position);
        holder.sub.setText(NoteModel.getN_sub());
        holder.dt.setText(NoteModel.getN_date_time());
//        holder.imgg.setImageBitmap(StringToBitmap(NoteModel.getN_img()));
    }

    @Override
    public int getItemCount() {
        return NoteModelsList.size();
    }

    public static Bitmap StringToBitmap(String encodedString) {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch (NullPointerException e) {
            e.getMessage();
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

}
