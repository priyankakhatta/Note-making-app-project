package com.pro.priyankakhatta.notemakingapplication;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.support.v4.widget.SimpleCursorAdapter;

import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FilterQueryProvider;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private NotesDBAdapter dbHelper;
    private SimpleCursorAdapter dataAdapter;
    private  ListView listview;
    Toolbar toolbar;
    EditText myFilter;
    int cursorValue = 0;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        listview = (ListView)findViewById(R.id.listview);

        dbHelper = new NotesDBAdapter(this);
        dbHelper.open();

        //Clean all data
//        //Add some data
        dbHelper.insertNotes();

        //Generate ListView from SQLite Database
        displayListView(0);
        dataAdapter.notifyDataSetChanged();

    }

    private void displayListView(int cursorValue) {


        switch (cursorValue){
            case 0:

                 cursor = dbHelper.fetchAllNotes();
                break;

            case 1:
                cursor = dbHelper.fetchAllNotesByAlpha();
                break;

            case 2:
                 cursor = dbHelper.fetchAllNotesByDate();
                break;

            default:
                     cursor = dbHelper.fetchAllNotes();


        }

        // The desired columns to be bound
        String[] columns = new String[] {
                NotesDBAdapter.KEY_N_SUB,
                NotesDBAdapter.KEY_N_DATETIME,
               // NotesDBAdapter.KEY_N_IMG

        };

        // the XML defined views which the data will be bound to
        int[] to = new int[] {
                R.id.sub,
                R.id.datetv,
          //      R.id.imag
        };

        // create the adapter using the cursor pointing to the desired data
        //as well as the layout information
        dataAdapter = new SimpleCursorAdapter(
                this, R.layout.listview_item,
                cursor,
                columns,
                to,
                0);

        // Assign adapter to ListView
        listview.setAdapter(dataAdapter);


        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view,
                                    int position, long id) {
                // Get the cursor, positioned to the corresponding row in the result set
                Cursor cursor = (Cursor) listView.getItemAtPosition(position);

//                // Get the state's capital from this row in the database.
                String idd = cursor.getString(cursor.getColumnIndexOrThrow("_id"));
                String s = cursor.getString(cursor.getColumnIndexOrThrow("sub"));
                String d = cursor.getString(cursor.getColumnIndexOrThrow("desc"));
                String dt = cursor.getString(cursor.getColumnIndexOrThrow("dt"));
                String la = cursor.getString(cursor.getColumnIndexOrThrow("lat"));
                String lg = cursor.getString(cursor.getColumnIndexOrThrow("lng"));
                String i = cursor.getString(cursor.getColumnIndexOrThrow("img"));


//                Toast.makeText(getApplicationContext(),
//                        countryCode, Toast.LENGTH_SHORT).show();


                Intent intnt = new Intent(MainActivity.this,AddNewNote.class);
                intnt.putExtra("id",idd);
                intnt.putExtra("sub",s);
                intnt.putExtra("desc",d);
                intnt.putExtra("dt",dt);
                intnt.putExtra("lat",la);
                intnt.putExtra("lng",lg);
                intnt.putExtra("img",i);
                intnt.putExtra("up","up");

                startActivity(intnt);

            }
        });
        myFilter = (EditText) findViewById(R.id.myFilter);

        myFilter.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                dataAdapter.getFilter().filter(s.toString());
            }
        });

        dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
            public Cursor runQuery(CharSequence constraint) {
                return dbHelper.fetchNoteByName(constraint.toString());
            }
        });



        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null).show();

           Intent in = new Intent(MainActivity.this,AddNewNote.class);
                in.putExtra("id","");
                in.putExtra("sub","");
                in.putExtra("desc","");
                in.putExtra("date_time","");
                in.putExtra("lat","");
                in.putExtra("lng","");
                in.putExtra("img","");
                in.putExtra("up","");
                startActivity(in);

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.sort_date) {
            displayListView(2);
            return true;
        }
        if (id == R.id.sort_alpha) {
            displayListView(1);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {

            Intent intent = new Intent(MainActivity.this,Home.class);
            startActivity(intent);
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
