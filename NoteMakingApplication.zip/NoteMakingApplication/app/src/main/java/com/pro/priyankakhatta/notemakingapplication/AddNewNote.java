package com.pro.priyankakhatta.notemakingapplication;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by priyankakhatta on 2017-12-14.
 */

public class AddNewNote extends AppCompatActivity  {

    private NotesDBAdapter dbHelper;
    public TextView date, lat_lng;
    public EditText sub_Et, desc_ET;
    public ImageView imgviewpic;
    public Button save_button,show_map;

    protected LocationManager locationManager;
    protected LocationListener locationListener;


    String idd= "", up ="", n_sub_str="" , n_desc_str="", dt="", lt = "0", lg = "0",lt_lg = "0", bit_img ="";
//    Location location;
//    protected double latitude;
//    protected double longitude;
//    protected boolean isGPSEnabled, isNetworkEnabled,canGetLocation;
    int MIN_TIME_BW_UPDATES = 1;
    int MIN_DISTANCE_CHANGE_FOR_UPDATES = 10;
    int REQUEST_CAMERA = 0;
    int SELECT_FILE = 1;
    String userChoosenTask = "";
   Toolbar toolbar;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_new_note);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        date = (TextView) findViewById(R.id.date);
//        lat_lng = (TextView) findViewById(R.id.lat_lng);
        sub_Et = (EditText) findViewById(R.id.sub_Et);
        desc_ET = (EditText) findViewById(R.id.desc_ET);
        imgviewpic = (ImageView) findViewById(R.id.imgviewpic);
        save_button = (Button) findViewById(R.id.save_button);
//        show_map = (Button)findViewById(R.id.show_map);

        dbHelper = new NotesDBAdapter(this);
        dbHelper.open();

        Calendar c = Calendar.getInstance();
        System.out.println("Current time : " + c.getTime());
        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm");
        final String formattedDate = df.format(c.getTime());

        date.setText(formattedDate);

        Intent intent = getIntent();
        idd = intent.getStringExtra("id");
        n_sub_str = intent.getStringExtra("sub");
        n_desc_str = intent.getStringExtra("desc");
        dt = intent.getStringExtra("dt");
        lt = intent.getStringExtra("lat");
        lg = intent.getStringExtra("lng");
        bit_img = intent.getStringExtra("img");
        up = intent.getStringExtra("up");


        sub_Et.setText(n_sub_str);
        desc_ET.setText(n_desc_str);

//        lat_lng.setText(lt+" , "+lg);
        imgviewpic.setImageBitmap(StringToBitmap(bit_img));
        date.setText(formattedDate);

        if(up.equals("")) {
            save_button.setText("Save");
        }

        else {
            save_button.setText("Update");
            date.setText(dt);

        }


//        locationManager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
//        // getting GPS status
//        isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
//        // getting network status
//        isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
//        if (!isGPSEnabled && !isNetworkEnabled) {
//            // no network provider is enabled
//        } else {
//            this.canGetLocation = true;
//            if (isNetworkEnabled) {
//                locationManager.requestLocationUpdates(
//                        LocationManager.NETWORK_PROVIDER,
//                        MIN_TIME_BW_UPDATES,
//                        MIN_DISTANCE_CHANGE_FOR_UPDATES, (LocationListener) this);
//                Log.d("activity", "LOC Network Enabled");
//                if (locationManager != null) {
//                    location = locationManager
//                            .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
//                    if (location != null) {
//                        Log.d("activity", "LOC by Network");
//                        latitude = location.getLatitude();
//                        longitude = location.getLongitude();
//                        lat_lng.setText("Lat. : "+latitude+"Long. : "+longitude);
//                        lt = String.valueOf(latitude);
//                        lg = String.valueOf(longitude);
//                    }
//                }
//            }
//            // if GPS Enabled get lat/long using GPS Services
//            if (isGPSEnabled) {
//                if (location == null) {
//                    locationManager.requestLocationUpdates(
//                            LocationManager.GPS_PROVIDER,
//                            MIN_TIME_BW_UPDATES,
//                            MIN_DISTANCE_CHANGE_FOR_UPDATES, (LocationListener) this);
//                    Log.d("activity", "RLOC: GPS Enabled");
//                    if (locationManager != null) {
//                        location = locationManager
//                                .getLastKnownLocation(LocationManager.GPS_PROVIDER);
//                        if (location != null) {
//                            Log.d("activity", "RLOC: loc by GPS");
//
//                            latitude = location.getLatitude();
//                            longitude = location.getLongitude();
//                            lat_lng.setText("Lat. : "+latitude+"Long : "+longitude);
//                            lt = String.valueOf(latitude);
//                            lg = String.valueOf(longitude);
//
//                        }
//                    }
//                }
//
//            }
//        }
//

        imgviewpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });



        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                n_sub_str = sub_Et.getText().toString();
                n_desc_str = desc_ET.getText().toString();
//                lt_lg = lat_lng.getText().toString();
                dt = formattedDate;


                if(up.equals("")) {
                    dbHelper.createNote(n_sub_str, n_desc_str, dt, lt, lg, bit_img);
                }
            else {
                    dbHelper.updateNote(idd, n_sub_str, n_desc_str, dt, lt, lg, bit_img);
                }
                Intent intnt = new Intent(AddNewNote.this,MainActivity.class);
                startActivity(intnt);
                finish();
            }
        });

//        show_map.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                showSettingAlert();
//
//                if (isGPSEnabled) {
//                    Intent intn = new Intent(AddNewNote.this, ShowMap.class);
//                    intn.putExtra("lat", lt);
//                    intn.putExtra("lng", lg);
//                    startActivity(intn);
//                }
//            }
//        });
    }


    public void showSettingAlert()
    {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle("GPS setting!");
        alertDialog.setMessage("GPS is not enabled, Do you want to go to settings menu? ");
        alertDialog.setPositiveButton("Setting", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    private void selectImage() {

        final CharSequence[] items = { "Take Photo", "Choose from Library",
                "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(AddNewNote.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result= Utility.checkPermission(AddNewNote.this);
                if (items[item].equals("Take Photo")) {
                    userChoosenTask="Take Photo";
                    if(result)
                        cameraIntent();
                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask="Choose from Library";
                    if(result)
                        galleryIntent();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }


    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Bitmap bm=null;
        if (data != null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        imgviewpic.setImageBitmap(bm);
        bit_img = BitmapToString(bm);
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        imgviewpic.setImageBitmap(thumbnail);

        bit_img = BitmapToString(thumbnail);
    }


    public static String BitmapToString(Bitmap bitmap) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] b = baos.toByteArray();
            String temp = Base64.encodeToString(b, Base64.DEFAULT);
            return temp;
        } catch (NullPointerException e) {
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    public static Bitmap StringToBitmap(String encodedString) {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch (NullPointerException e) {
            e.getMessage();
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }
//    @Override
//    public void onLocationChanged(Location location) {
//        lat_lng.setText("Lat. : "+latitude+"Long. : "+longitude);
//        lt = String.valueOf(latitude);
//        lg = String.valueOf(longitude);
//    }
//
//    @Override
//    public void onStatusChanged(String provider, int status, Bundle extras) {
//
//        lat_lng.setText("Lat. : "+latitude+"Long. : "+longitude);
//        lt = String.valueOf(latitude);
//        lg = String.valueOf(longitude);
//    }
//
//    @Override
//    public void onProviderEnabled(String provider) {
//
//        lat_lng.setText("Lat. : "+latitude+"Long. : "+longitude);
//
//        lt = String.valueOf(latitude);
//        lg = String.valueOf(longitude);
//    }
//
//    @Override
//    public void onProviderDisabled(String provider) {
//
//    }

    public static class Utility {
        public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
        public static boolean checkPermission(final Context context)
        {
            int currentAPIVersion = Build.VERSION.SDK_INT;
            if(currentAPIVersion>=android.os.Build.VERSION_CODES.M)
            {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                        alertBuilder.setCancelable(true);
                        alertBuilder.setTitle("Permission necessary");
                        alertBuilder.setMessage("External storage permission is necessary");
                        alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                            }
                        });
                        AlertDialog alert = alertBuilder.create();
                        alert.show();
                    } else {
                        ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                    }
                    return false;
                } else {
                    return true;
                }
            } else {
                return true;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(userChoosenTask.equals("Take Photo"))
                        cameraIntent();
                    else if(userChoosenTask.equals("Choose from Library"))
                        galleryIntent();
                } else {
                    //code for deny
                }
                break;
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
