package com.pro.priyankakhatta.notemakingapplication;

/**
 * Created by priyankakhatta on 2017-12-14.
 */

public class NoteModel {


    String n_sub = null;
    String n_desc = null;
    String n_date_time = null;
    String n_LAT = null;
    String n_LNG = null;
    String n_img = null;


    public NoteModel(String n_sub, String n_desc, String n_date_time, String n_LAT, String n_LNG, String n_img ) {
        this.n_sub=n_sub;
        this.n_desc=n_desc;
        this.n_date_time=n_date_time;
        this.n_LAT=n_LAT;
        this.n_LNG=n_LNG;
        this.n_img=n_img;

    }
    public String getN_sub() {
        return n_sub;
    }

    public void setN_sub(String n_sub) {
        this.n_sub = n_sub;
    }

    public String getN_desc() {
        return n_desc;
    }

    public void setN_desc(String n_desc) {
        this.n_desc = n_desc;
    }

    public String getN_date_time() {
        return n_date_time;
    }

    public void setN_date_time(String n_date_time) {
        this.n_date_time = n_date_time;
    }

    public String getN_LAT() {
        return n_LAT;
    }

    public void setN_LAT(String n_LAT) {
        this.n_LAT = n_LAT;
    }

    public String getN_LNG() {
        return n_LNG;
    }

    public void setN_LNG(String n_LNG) {
        this.n_LNG = n_LNG;
    }

    public String getN_img() {
        return n_img;
    }

    public void setN_img(String n_img) {
        this.n_img = n_img;
    }


}
