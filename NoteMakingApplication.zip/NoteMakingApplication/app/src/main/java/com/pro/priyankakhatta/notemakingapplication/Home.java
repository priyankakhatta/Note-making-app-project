package com.pro.priyankakhatta.notemakingapplication;

/**
 * Created by priyankakhatta on 2017-12-14.
 */


import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.FilterQueryProvider;
import android.widget.SimpleCursorAdapter;

public class Home extends AppCompatActivity {

    private NotesDBAdapter dbHelper;
    private SimpleCursorAdapter dataAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dbHelper = new NotesDBAdapter(this);
        dbHelper.open();

//Clean all data
        dbHelper.deleteAllNotes();
//Add some data
        dbHelper.insertNotes();

//Generate ListView from SQLite Database
        displayListView();

    }

    private void displayListView() {


        Cursor cursor = dbHelper.fetchAllNotes();

// The desired columns to be bound
        String[] columns = new String[] {
                NotesDBAdapter.KEY_N_SUB,
                NotesDBAdapter.KEY_N_DESC,
                NotesDBAdapter.KEY_N_DATETIME,
                NotesDBAdapter.KEY_N_LAT,
                NotesDBAdapter.KEY_N_LNG,
                NotesDBAdapter.KEY_N_IMG
        };


        EditText myFilter = (EditText) findViewById(R.id.myFilter);
        myFilter.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                dataAdapter.getFilter().filter(s.toString());
            }
        });

        dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
            public Cursor runQuery(CharSequence constraint) {
                return dbHelper.fetchNoteByName(constraint.toString());
            }
        });

    }
}